<?php 
session_start();


  include_once('home.php');
  if(isset($_POST['insert']))
  {
    $Source=$_POST['Source'];
    $Destination=$_POST['Destination'];
    $Train_name=$_POST['Train_name'];
    $Dept_time=$_POST['Dept_time'];
    $Train_class=$_POST['Train_class'];
    $Station_name=$_POST['Station_name'];
    $Seat_category=$_POST['Seat_category'];
    $Payment=$_POST['Payment'];
    $passenger_name=$_POST['passenger_name'];
    $arrival_date=$_POST['arrival_date'];
        if(empty($Source)|| empty($Destination)|| empty($Train_name)|| empty($Dept_time)|| empty($Train_class)|| empty($Station_name)|| empty($Seat_category)||empty($Payment))
    {
      echo"<font color='red'>Field is empty</font></br>";
    }

    else
    {
      $sql="insert into book_ticket(Source,Destination,Train_name,Dept_time,arrival_date,Arrival_time,Train_class,Station_name,Seat_category,Payment,passenger_name) values('$Source','$Destination','$Train_name','$Dept_time','$arrival_date',' ','$Train_class','$Station_name','$Seat_category','$Payment','$passenger_name')";
      $result=mysqli_query($con,$sql);
      echo "<script>alert('Ticket Booked Successfully!!');</script>";
        echo"<br><a href='book_ticket.php'></a>";
    }

  }


if (isset($_SESSION['Name']) && isset($_SESSION['Username'])) {
  $p_name=$_SESSION['Name'];

 ?>
<!DOCTYPE html>
<html>
<head>
	<title>HOME</title>
  <script src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap4.min.js" type="text/javascript"></script>


<script src="https://code.jquery.com/jquery-3.5.1.js" type="text/javascript"></script>

<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js" type="text/javascript"></script>
 <script type="text/javascript">
   $(document).ready(function () {
    $('#example').DataTable();
});
 </script>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<link rel="stylesheet" href="Registration.css">
<style>
body {
  background: url(Railway2.jpg);
  background-position: center;
  background-size: cover;
  height: 100vh;
}
</style>
<style>
body {
  background: url(Railway.jpg);
	background-position: center;
	background-size: cover;
	height: 100vh;
}
</style>
</head>
<body>
	 
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#"> Railway Management System</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="home2.php">Home</a>
        </li>
        
       
       <li class="nav-item">
          <a class="nav-link" href="book_ticket.php">Book</a>
        </li>
          <li class="nav-item">
          <a class="nav-link" href="booking_history.php">Booking History</a>
        </li>
       
        <li class="nav-item">
          <a class="nav-link" href="contract_us.php">Contact us</a>
        </li>
         <li class="nav-item">
          <a class="nav-link" href="profile.php">Profile</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="logout.php">Logout</a>
        </li>

      </ul>
      
    </div>
  </div>
</nav>

<h1 align="center" color="white"><?php echo $_SESSION['Username']; ?>, Welcome to our website</h1>
<div class="content">
<div class="form">
<form action="book_ticket.php" method="post">
  <div class="row mb-3">
        <label for="inputName" class="col-sm-2 col-form-label">Source</label>
        <div class="col-sm-6">
          <select name="Source" class="form-control">
            <option value="Dhaka">Dhaka</option>
            <option value="Comilla">Comilla</option>
            <option value="Barishal">Barishal</option>
            <option value="Chattogram">Chattogram</option>
            <option value="Khulna">Khulna</option>
          </select>

          
        </div>
    </div>
    <div class="row mb-3">
        <label for="inputPassword" class="col-sm-2 col-form-label">Seat_category</label>
        <div class="col-sm-6">
             <select name="Seat_category" class="form-control">
              <option value="Adult">Adult</option>
              <option value="child">child</option>
              <option value="Disable">Disable</option>
              <option value="Ladies">Ladies</option>
             </select>
          
        </div>
    </div>
    <div class="row mb-3">
        <label for="inputSurname" class="col-sm-2 col-form-label">Destination</label>
        <div class="col-sm-6">
            <select name="Destination" class="form-control">
          <option value="Dhaka">Dhaka</option>
            <option value="Comilla">Comilla</option>
            <option value="Barishal">Barishal</option>
            <option value="Chattogram">Chattogram</option>
            <option value="Khulna">Khulna</option>
          </select>
         
        </div>
    </div>
    <div class="row mb-3">
        <label for="inputUsername" class="col-sm-2 col-form-label">Train Name</label>
        <div class="col-sm-6">
          <select name="Train_name" class="form-control">
          <?php
          $sql = "SELECT * FROM trains where available='Available'";
                  $result = $con->query($sql);
                  if ($result->num_rows > 0) {
                   // output data of each row
                     while($row = $result->fetch_assoc()) {
          ?>
            
            <option value="<?php echo $row['train_name'];?>"><?php echo $row['train_name']; ?></option>
           
            <?php
          }}
            ?>
          </select>
            
        </div>
    </div>
 <div class="row mb-3">
        <label for="inputGender" class="col-sm-2 col-form-label">Arrival Date</label>
        <div class="col-sm-6">
            <input type="date" name="arrival_date" class="form-control" id="inputGender" placeholder="Departure Time">
        </div>
    </div>

    <div class="row mb-3">
        <label for="inputGender" class="col-sm-2 col-form-label">Departure Time</label>
        <div class="col-sm-6">
            <input type="time" name="Dept_time" class="form-control" id="inputGender" placeholder="Departure Time">
        </div>
    </div>

       <input type="hidden" name="passenger_name" class="form-control" id="inputGender" value="<?php echo $p_name;?>" placeholder="Departure Time">
    <div class="row mb-3">
        <label for="inputEmail" class="col-sm-2 col-form-label">Train Class</label>
        <div class="col-sm-6">
         <select name="Train_class" class="form-control">
            <option value="AC">AC</option>
            <option value="Non-AC">NON-AC</option>
            <option value="Souvan Chair">Souvab Chair</option>
          
          </select>
            
        </div>
    </div>
    
    <div class="row mb-3">
        <label for="inputPassword" class="col-sm-2 col-form-label">Station Name</label>
       <div class="col-sm-6">
             <select name="Station_name" class="form-control">
               <option value="Dhaka">Dhaka</option>
            <option value="Comilla">Comilla</option>
            <option value="Barishal">Barishal</option>
            <option value="Chattogram">Chattogram</option>
            <option value="Khulna">Khulna</option>
          </select>
          
        </div>
    </div>
     <div class="row mb-3">
     <a href="https://buy.stripe.com/test_4gw29f1Dt2e7664144">confirm your payment</a>
        <label for="inputPassword" class="col-sm-2 col-form-label">Payment</label>
        <div class="col-sm-6">
            <input type="number" name="Payment" value="500" class="form-control" id="inputPassword" placeholder="Password" readonly="">
        </div>
    </div>
                <div class="inputBox">
                    <span class=" text-white">cards accepted :</span>
                    <img src="https://img.icons8.com/color/48/000000/visa.png"/>
            	<img src="https://img.icons8.com/color/48/000000/mastercard.png"/>
            	<img src="https://img.icons8.com/color/48/000000/paypal.png"/>
            	<img src="https://img.icons8.com/color/48/000000/bank-card-back-side.png"/>
            	<img src="https://img.icons8.com/color/48/000000/amex.png"/>
                </div>
    <form method="post"> 
            <input type="submit" value="submit"class="btn btn-warning text-black" name="insert"/> 
    </form>
</form>
</div>
</div>
</body>
</html>

<?php 
}else{
     header("Location: index2.php");
     exit();
}
 ?>