<?php
$id=$_GET['id'];

  include_once('home.php');

$sql="DELETE FROM book_ticket where id ='$id'";
  $result=mysqli_query($con,$sql);
   header('Location: admin_home.php');


?>