<?php
require_once'home.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>View data</title>
  
  <script src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap4.min.js" type="text/javascript"></script>


<script src="https://code.jquery.com/jquery-3.5.1.js" type="text/javascript"></script>

<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js" type="text/javascript"></script>
 <script type="text/javascript">
   $(document).ready(function () {
    $('#example').DataTable();
});
 </script>

 <style type="text/css">
   #example{
    margin: auto;
   }
 </style>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/css/bootstrap.min.css" integrity="sha384-r4NyP46KrjDleawBgD5tp8Y7UzmLA05oM1iAEQ17CSuDqnUK2+k9luXQOfXJCJ4I" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap4.min.css">
</head>
<body>
      <nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#"> Railway Management System</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="admin_home.php">Home</a>
        </li>
           <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="contract.php">Messages</a>
        </li>
         <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="train_list.php">Train List</a>
        </li>
        
   
     
        
      
        <li class="nav-item">
          <a class="nav-link" href="adminlogin.php">Logout</a>
        </li>

      </ul>
      
    </div>
  </div>
</nav>
<div class="container">
    <div class="row">
        <div class="col-md-12">
           
            
            <div class="table-responsive">
            <table id="example" class="table table-striped table-bordered">
                    <thead>   
                        <th>id</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Message</th>
                        
                    </thead>

                    <tbody>
                        <?php
                        $sql = mysqli_query($con,"CALL read_data2()");
                        $cnt = 0;
                        $row = mysqli_num_rows($sql);

                        if($row > 0)
                        {
                            while($result = mysqli_fetch_array($sql))
                            {
                                ?>
                                <tbody>
                                <tr>
                                    <td><?php echo $cnt;?></td> 
                                    <td><?php echo $result['FirstName']; ?></td>
                                    <td><?php echo $result['LastName']; ?></td>
                                    <td><?php echo $result['Message']; ?></td>
                                    
                                </tr>
                                </tbody>
                                <?php
                                    $cnt++;
                            }
                        }
                        else{
                            ?>
                            <tr>
                                <td>No Record Found!</td>
                            </tr>
                        <?php } ?>
                    </tbody>

                </table>
            </div>
        </div>
    </div>
</div>
</body>
</html>