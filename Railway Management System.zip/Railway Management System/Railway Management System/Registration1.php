<?php
include_once("home.php");
$sql="SELECT * from home.php";
$result=mysqli_query($con,$sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="" ="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width,initial-scale=1.0">
	<title>Registration</title>
</head>
<body>

	<table width='80%'>
		<tr bgcolor="grey">
		    <td>First name</td>
		    <td>Surname</td>
		    <td>Gender</td>
		    <td>ID</td>
		    <td>Email</td>
		    <td>Password</td>
		    
		</tr>
	    <?php
	    while($r=mysqli_fetch_array($result))
	    {
	    	echo "<tr>";
	    	echo "<td>".$r['First name']."</td>";
	    	echo "<td>".$r['Surname']."</td>";
	    	echo "<td>".$r['Gender']."</td>";
	    	echo "<td>".$r['ID']."</td>";
	    	echo "<td>".$r['Email']."</td>";
	    	echo "<td>".$r['Password']."</td>";
	    	echo "</tr>";

	    }
	    ?>
	</table>
</body>
</html>