<?php 
session_start();
$id=$_GET['id'];


  include_once('home.php');

  if (isset($_POST['submit'])) {
    # code...
    $Train_Name=$_POST['Train_Name'];
    $available=$_POST['available'];
    $id=$_POST['train_id'];
  
    
  $sql="UPDATE trains SET available='$available' where train_id='$id'";
  
  if ($con->query($sql) === TRUE) {
    # code...
    header("Location:train_list.php");
  }
  else{

  }
  }
  


  

if (isset($_SESSION['Username'])) {
  $p_name=$_SESSION['Username'];

 ?>
<!DOCTYPE html>
<html>
<head>
  <title>HOME</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<link rel="stylesheet" href="Registration.css">
<style>
body {

  background-position: center;
  background-size: cover;
  height: 100vh;
}
</style>
<style>
body {
  
  background-position: center;
  background-size: cover;
  height: 100vh;
}
</style>
</head>
<body>
   
     <nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#"> Railway Management System</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
       <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="admin_home.php">Home</a>
        </li>
         <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="contract.php">Messages</a>
        </li>
         <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="train_list.php">Train List</a>
        </li>
   
     
        
      
        <li class="nav-item">
          <a class="nav-link" href="adminlogin.php">Logout</a>
        </li>

      </ul>
      
    </div>
  </div>
</nav>
<h1 align="center" color="white"><?php echo $_SESSION['Username']; ?>, Welcome to our website</h1>
 <?php
$sql = "SELECT * FROM trains where train_id='$id'";
                  $result = $con->query($sql);
                  
                   // output data of each row
                     $row = $result->fetch_assoc();
                    
 ?>

<div class="content">
<div class="form">
 <form class="form-horizontal" action="update_train.php" method="POST">
    <div class="form-group">
      <label class="control-label col-sm-2" for="email">Train Name:</label>
      <div class="col-sm-10">
         <input type="hidden" class="form-control" id="Name" placeholder="Enter Train name" name="train_id" value="<?php echo $row['train_id']?>">
        <input type="text" class="form-control" id="Name" placeholder="Enter Train name" name="Train_Name" value="<?php echo $row['train_name']?>">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="email">Available:</label>
      <div class="col-sm-10">
        <select class="form-control" name="available">
          <option value="<?php echo $row['available'];?>"><?php echo $row['available'];?></option>
          <option value="Available">Available</option>
          <option value="Not Available">Not Available</option>
        </select>
        
      </div>
    </div>
    
  
    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
        <input type="submit" name="submit" value="Submit">
         </div>
    </div>
  </form>
</div>
</div>
</body>
</html>

<?php 
}else{
     header("Location: index2.php");
     exit();
}
 ?>