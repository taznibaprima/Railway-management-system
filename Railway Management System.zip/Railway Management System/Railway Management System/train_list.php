<?php 
session_start();


  include_once('home.php');
  

if (isset($_SESSION['Username'])) {
  $p_name=$_SESSION['Username'];

 ?>
<!DOCTYPE html>
<html>
<head>
  <title>HOME</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<link rel="stylesheet" href="Registration.css">
<style>
body {

  background-position: center;
  background-size: cover;
  height: 100vh;
}
</style>
<style>
body {
  
  background-position: center;
  background-size: cover;
  height: 100vh;
}
</style>
</head>
<body>
   
     <nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#"> Railway Management System</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="admin_home.php">Home</a>
        </li>
         <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="contract.php">Messages</a>
        </li>
         <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="train_list.php">Train List</a>
        </li>
        
   
     
        
      
        <li class="nav-item">
          <a class="nav-link" href="adminlogin.php">Logout</a>
        </li>

      </ul>
      
    </div>
  </div>
</nav>
<h1 align="center" color="white"><?php echo $_SESSION['Username']; ?>, Welcome to our website</h1>
<a class="btn btn-primary" href="add_train.php">Add Train</a>
 

<div class="content">
<div class="form">

<table class="table table-bordered">
  <tr>
    <th>Train Name</th>
    <th>Station Name</th>
    <th>Available</th>
  
    <th>Action</th>
  </tr>
  <?php
 $sql = "SELECT * FROM trains ";
                  $result = $con->query($sql);
                  if ($result->num_rows > 0) {
                   // output data of each row
                     while($row = $result->fetch_assoc()) {
                    
                    
                  ?>
                  <tr>
                  <td><?php echo $row['train_name'];?></td>
                  <td><?php echo $row['station_name'];?></td>
                  <td><?php echo $row['available'];?></td>
               
                  <td>
                    <a href="update_train.php?id=<?php echo $row['train_id']?>">Edit</a>
                        
                  </td>

                 </tr>




                  <?php
                    }
                  }
                  ?>

</table>
</div>
</div>
</body>
</html>

<?php 
}else{
     header("Location: index2.php");
     exit();
}
 ?>