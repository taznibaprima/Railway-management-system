<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="" ="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>Registration</title>
</head>
<body>
	<?php
	include_once('home.php');
	if(isset($_POST['submit']))
	{
		$Name=$_POST['Name'];
		$Surname=$_POST['Surname'];
		$Gender=$_POST['Gender'];
		$ID=$_POST['ID'];
        $Email=$_POST['Email'];
		$Password=$_POST['Password'];
        if(empty($Name)|| empty($Surname)|| empty($ID)|| empty($Email)|| empty($Password))
		{
			echo"<font color='red'>Field is empty</font></br>";
		}

		else
		{
			$sql="insert into passenger(Name,Surname,Gender,ID,Email,Password) values('$Name','$Surname','$Gender','$ID','$Email','$Password')";
			$result=mysqli_query($con,$sql);
			echo"<font color='green'>Registered Successfully</font>";
		    echo"<br><a href='Registration1.php'>View All</a>";
		}

	}
	?>
</body>
</html>