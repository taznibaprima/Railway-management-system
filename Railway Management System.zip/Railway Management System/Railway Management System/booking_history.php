<?php 
session_start();


  include_once('home.php');
  

if (isset($_SESSION['Name']) && isset($_SESSION['Username'])) {
  $p_name=$_SESSION['Name'];

 ?>
<!DOCTYPE html>
<html>
<head>
  <title>HOME</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<link rel="stylesheet" href="Registration.css">
<style>
body {

  background-position: center;
  background-size: cover;
  height: 100vh;
}
</style>
<style>
body {
  
  background-position: center;
  background-size: cover;
  height: 100vh;
}
</style>
</head>
<body>
   
   <nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#"> Railway Management System</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="home2.php">Home</a>
        </li>
        
       
       <li class="nav-item">
          <a class="nav-link" href="book_ticket.php">Book</a>
        </li>
          <li class="nav-item">
          <a class="nav-link" href="booking_history.php">Booking History</a>
        </li>
       
        <li class="nav-item">
          <a class="nav-link" href="contract_us.php">Contact us</a>
        </li>
         <li class="nav-item">
          <a class="nav-link" href="profile.php">Profile</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="logout.php">Logout</a>
        </li>

      </ul>
      
    </div>
  </div>
</nav>

<h1 align="center" color="white"><?php echo $_SESSION['Username']; ?>, Welcome to our website</h1>
<div class="content">
<div class="form">

<table class="table table-bordered">
  <tr>
    <th>Passenger Name</th>
    <th>Source</th>
    <th>Destination</th>
    <th>Arrival Date</th>
    <th>Departure Time</th>
    <th>Payment</th>
    <th>Status</th>
  </tr>
  <?php
$count=0;
 $sql = "SELECT * FROM book_ticket where passenger_name='$p_name'";
                  $result = $con->query($sql);
                  if ($result->num_rows > 0) {
                   // output data of each row
                     while($row = $result->fetch_assoc()) {
                    $count++;
                    
                  ?>
                  <tr>
                  <td><?php echo $row['passenger_name'];?></td>
                  <td><?php echo $row['Source'];?></td>
                  <td><?php echo $row['Destination'];?></td>
                  <td><?php echo $row['arrival_date'];?></td>
                  <td><?php echo $row['Dept_time'];?></td>
                  <td><?php echo $row['Payment'];?></td>
                  <td><?php echo $row['status'];?></td>

                 </tr>




                  <?php
                    }
                  }
                  ?>

</table>
</div>
</div>
</body>
</html>

<?php 
}else{
     header("Location: index2.php");
     exit();
}
 ?>