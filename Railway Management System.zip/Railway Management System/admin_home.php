<?php 
session_start();


  include_once('home.php');
  
?>

<!DOCTYPE html>
<html>
<head>
  <title>HOME</title>
 
<script src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap4.min.js" type="text/javascript"></script>


<script src="https://code.jquery.com/jquery-3.5.1.js" type="text/javascript"></script>

<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js" type="text/javascript"></script>
 <script type="text/javascript">
   $(document).ready(function () {
    $('#example').DataTable();
});
 </script>

 <style type="text/css">
   #example{
    margin: auto;
   }
 </style>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/css/bootstrap.min.css" integrity="sha384-r4NyP46KrjDleawBgD5tp8Y7UzmLA05oM1iAEQ17CSuDqnUK2+k9luXQOfXJCJ4I" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap4.min.css">

  <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/js/bootstrap.min.js" integrity="sha384-oesi62hOLfzrys4LxRF63OJCXdXDipiYWBnvTl9Y9/TRlw5xlKIEHpNyvvDShgf/" crossorigin="anonymous"></script>

<link rel="stylesheet" href="Registration.css">
<style>
body {

  background-position: center;
  background-size: cover;
  height: 100vh;
}
</style>
<style>
body {
  
  background-position: center;
  background-size: cover;
  height: 100vh;
}
</style>
</head>
<body>
   
     <nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#"> Railway Management System</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="home2.php">Home</a>
        </li>
           <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="contract.php">Messages</a>
        </li>
         <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="train_list.php">Train List</a>
        </li>
        
   
     
        
      
        <li class="nav-item">
          <a class="nav-link" href="adminlogin.php">Logout</a>
        </li>

      </ul>
      
    </div>
  </div>
</nav>
<div class="container">
<h1 align="center" color="white"><?php echo $_SESSION['Username']; ?></h1>
<div class="content">
  <div class="table-responsive">
<table id="example" class="table table-striped table-bordered">
  <thead>
  <tr>
    <th>Passenger Name</th>
    <th>Source</th>
    <th>Destination</th>
  
    <th>Departure Time</th>
    <th>Seat_category</th>
    <th>Payment</th>
    <th>Status</th>
    <th>Action</th>
  </tr>
  </thead>
  <?php
$count=0;
 $sql = "SELECT * FROM book_ticket ";
                  $result = $con->query($sql);
                  if ($result->num_rows > 0) {
                   // output data of each row
                     while($row = $result->fetch_assoc()) {
                    $count++;
                    
                  ?>
                  <tbody>
                  <tr>
                  <td><?php echo $row['passenger_name'];?></td>
                  <td><?php echo $row['Source'];?></td>
                  <td><?php echo $row['Destination'];?></td>
                 
                  <td><?php echo $row['Dept_time'];?></td>
                  <td><?php echo $row['Seat_category'];?></td>
                  <td><?php echo $row['Payment'];?></td>
                  <td><?php echo $row['status'];?></td>
                  <td>
                    <a href="update_ticket.php?id=<?php echo $row['id']?>">Edit</a>
                     <a href="delete_ticket.php?id=<?php echo $row['id']?>">Delete</a>
                     
                  </td>

                 </tr>

</tbody>


                  <?php
                    }
                  }
                  ?>

</table>
</div>
</div>
</div>
</body>
</html>


