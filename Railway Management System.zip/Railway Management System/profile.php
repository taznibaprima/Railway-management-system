<?php
session_start();
require_once'home.php';
$name=$_SESSION['Name'];
if(isset($_POST['Update']))
{
    $Sname = $_POST['Surname'];
    $Email = $_POST['Email'];
    $Password = $_POST['Password'];
    $name = $_POST['Name'];
    $gender=$_POST['gender'];
    $sql = mysqli_query($con,"UPDATE passenger SET  Name='$name',Surname='Sname',Email='$Email',Password='$Password' where Name='$name'");

    if($sql)
    {
        echo "<script>alert('Data Updated successfully!');</script>";
    }
    else
    {
        echo "<script>alert('Error!');</script>";
    }
}


?>



<!DOCTYPE html>
<html>
<head>
    <title>Registration page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<link rel="stylesheet" href="Registration.css">
<style>
body {
  background: url(Railway2.jpg);
  background-position: center;
  background-size: cover;
  height: 100vh;
}
</style>
</head>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#"> Railway Management System</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="home2.php">Home</a>
        </li>
        
       
       <li class="nav-item">
          <a class="nav-link" href="book_ticket.php">Book</a>
        </li>
          <li class="nav-item">
          <a class="nav-link" href="booking_history.php">Booking History</a>
        </li>
       
        <li class="nav-item">
          <a class="nav-link" href="contract_us.php">Contact us</a>
        </li>
         <li class="nav-item">
          <a class="nav-link" href="profile.php">Profile</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="logout.php">Logout</a>
        </li>

      </ul>
      
    </div>
  </div>
</nav>


<?php
$sql1 = "SELECT * FROM passenger where Name='$name'";
$result = $con->query($sql1);
$row = $result->fetch_assoc();
?>
<div class="content">
<div class="form">
<form action=" " method="post">
  <div class="row mb-3">
       
        <div class="col-sm-6">
            <input type="hidden" name="name" class="form-control" id="inputFirstname" placeholder="First name" value="<?php echo $name;?>">
            <input type="hidden" name="gender" class="form-control" id="inputFirstname" placeholder="First name" value="<?php echo $row['Gender'];?>">
        </div>
    </div>
    <div class="row mb-3">
        <label for="inputSurname" class="col-sm-2 col-form-label">Surname</label>
        <div class="col-sm-6">
            <input type="name" name="Surname" class="form-control" id="inputSurname" placeholder="Surname" value="<?php echo $row['Surname'];?>">
        </div>
    </div>
  
    <div class="row mb-3">
        <label for="inputEmail" class="col-sm-2 col-form-label">Email</label>
        <div class="col-sm-6">
            <input type="email" name="Email" class="form-control" id="inputEmail" placeholder="Email"value="<?php echo $row['Email'];?>">
        </div>
    </div>
    
    <div class="row mb-3">
        <label for="inputPassword" class="col-sm-2 col-form-label">Password</label>
        <div class="col-sm-6">
            <input type="password" name="Password" class="form-control" id="inputPassword" placeholder="Password" value="<?php echo $row['Password'];?>">
        </div>
    </div>
    <form method="post"> 
            <input type="submit" value="Update" name="Update"/> 
    </form>
</form>
</div>
</div>
</body>
</html>