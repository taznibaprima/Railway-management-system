<?php
$host="localhost:3306";
$dbname="railway";
$dbusername="root";
$dbpassword="";
$con=mysqli_connect($host,$dbusername,$dbpassword,$dbname);

if(mysqli_connect_errno())
{
	echo "Connection failed:".mysqli_connect_errno;
	exit();
}
else
{
	echo "";
}
?>