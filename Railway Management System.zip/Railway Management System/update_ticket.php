<?php 
session_start();
$id=$_GET['id'];


  include_once('home.php');
  if(isset($_POST['update']))
  {
    $id=$_POST['id'];
    $Source=$_POST['Source'];
    $Destination=$_POST['Destination'];
    $Train_name=$_POST['Train_name'];
    $Train_class=$_POST['Train_class'];
    $Station_name=$_POST['Station_name'];
    $Seat_category=$_POST['Seat_category'];
    $Payment=$_POST['Payment'];
    $passenger_name=$_POST['passenger_name'];
    $arrival_date=$_POST['arrival_date'];
    $status=$_POST['status'];
        if(empty($Source)|| empty($Destination)|| empty($Train_name)|| empty($Train_class)|| empty($Station_name)|| empty($Seat_category)|| empty($Payment))
    {
      echo"<font color='red'>Field is empty</font></br>";
    }

    else
    {
      $sql="UPDATE book_ticket SET Source='$Source', Destination='$Destination', Train_name='$Train_name',Train_class='$Train_class', Station_name='$Station_name',Seat_category='$Seat_category',Payment='$Payment',status='$status' where id='$id'";
      $result=mysqli_query($con,$sql);
      echo "<a href='admin_home.php'></a>
     ";
    }

  }


if ( isset($_SESSION['Username'])) {
 

 ?>
<!DOCTYPE html>
<html>
<head>
	<title>HOME</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<link rel="stylesheet" href="Registration.css">
<style>
body {
  background: url(Railway2.jpg);
  background-position: center;
  background-size: cover;
  height: 100vh;
}
</style>
<style>
body {
  background: url(Railway.jpg);
	background-position: center;
	background-size: cover;
	height: 100vh;
}
</style>
</head>
<body>
	 
     <nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#"> Railway Management System</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="admin_home.php">Home</a>
        </li>
        
   
     
        <li class="nav-item">
          <a class="nav-link" href="adminlogin.php">Logout</a>
        </li>

      </ul>
      
    </div>
  </div>
</nav>
<?php

 $sql = "SELECT * FROM book_ticket where id='$id'";
                  $result = $con->query($sql);
               
                   $row = $result->fetch_assoc();
                  
                    
                  ?>
<h1 align="center" color="white"><?php echo $_SESSION['Username']; ?></h1>
<div class="content">
<div class="form">
<form action="update_ticket.php" method="post">
   <input type="hidden" name="id" class="form-control" id="inputGender" value="<?php echo $row['id']?>" >
  <div class="row mb-3">
        <label for="inputName" class="col-sm-2 col-form-label">Source</label>
        <div class="col-sm-6">
          <select name="Source" class="form-control">
            <option value="<?php echo $row['Source']; ?>"><?php echo $row['Source']; ?></option>
            <option value="Dhaka">Dhaka</option>
            <option value="Comilla">Comilla</option>
            <option value="Barishal">Barishal</option>
            <option value="Chattogram">Chattogram</option>
            <option value="Khulna">Khulna</option>
         
          </select>
          
        </div>
    </div>

    <div class="row mb-3">
        <label for="inputPassword" class="col-sm-2 col-form-label">Seat_category</label>
        <div class="col-sm-6">
             <select name="Seat_category" class="form-control">
             <option value="<?php echo $row['Seat_category']; ?>"><?php echo $row['Seat_category']; ?></option>
              <option value="Adult">Adult</option>
              <option value="child">child</option>
              <option value="Disable">Disable</option>
              <option value="Ladies">Ladies</option>
             </select>
          
        </div>
    </div>
    <div class="row mb-3">
        <label for="inputSurname" class="col-sm-2 col-form-label">Destination</label>
        <div class="col-sm-6">
            <select name="Destination" class="form-control">
        <option value="<?php echo $row['Destination']; ?>"><?php echo $row['Destination']; ?></option>
          <option value="Dhaka">Dhaka</option>
            <option value="Comilla">Comilla</option>
            <option value="Barishal">Barishal</option>
            <option value="Chattogram">Chattogram</option>
            <option value="Khulna">Khulna</option>
          </select>
         
        </div>
    </div>
    <div class="row mb-3">
        <label for="inputUsername" class="col-sm-2 col-form-label">Train Name</label>
        <div class="col-sm-6">
            <select name="Train_name" class="form-control">
                <option value="<?php echo $row['Train_name']; ?>"><?php echo $row['Train_name']; ?></option>
            <option value="Turna Express">Turna Express</option>
            <option value="Suborna Express">Suborna Express</option>
            <option value="Godhuli">Godhuli</option>
            <option value="Chattola Express">Chattola Express</option>
          </select>
            
        </div>
    </div>
 <div class="row mb-3">
        <label for="inputGender" class="col-sm-2 col-form-label">Arrival Date</label>
        <div class="col-sm-6">
            <input type="date" name="arrival_date" class="form-control" id="inputGender" value="<?php echo $row['arrival_date']?>" >
        </div>
    </div>
 <div class="row mb-3">
        <label for="inputGender" class="col-sm-2 col-form-label">Passenger Name</label>
        <div class="col-sm-6">
           <input type="text" name="passenger_name" class="form-control" id="inputGender" value="<?php echo $row['passenger_name'];?>" placeholder="Departure Time">
        </div>
    </div>
    

     
    <div class="row mb-3">
        <label for="inputEmail" class="col-sm-2 col-form-label">Train Class</label>
        <div class="col-sm-6">
 <select name="Train_class" class="form-control">
    <option value="<?php echo $row['Train_class']; ?>"><?php echo $row['Train_class']; ?></option>
            <option value="AC">AC</option>
            <option value="Non-AC">NON-AC</option>
            <option value="Souvan Chair">Souvab Chair</option>
          
          </select>
            
        </div>
    </div>
    
    <div class="row mb-3">
        <label for="inputPassword" class="col-sm-2 col-form-label">Station Name</label>
        <div class="col-sm-6">
             <select name="Station_name" class="form-control">
                <option value="<?php echo $row['Station_name']; ?>"><?php echo $row['Station_name']; ?></option>
               <option value="Dhaka">Dhaka</option>
            <option value="Comilla">Comilla</option>
            <option value="Barishal">Barishal</option>
            <option value="Chattogram">Chattogram</option>
            <option value="Khulna">Khulna</option>
          </select>
          
        </div>
    </div>
     <div class="row mb-3">
        <label for="inputPassword" class="col-sm-2 col-form-label">Payment</label>
        <div class="col-sm-6">
         
            <input type="number" name="Payment" value="500" class="form-control" id="inputPassword" placeholder="Password" readonly="">
        </div>
    </div>

    <div class="row mb-3">
        <label for="inputPassword" class="col-sm-2 col-form-label">Status</label>
        <div class="col-sm-6">
           <select name="status" class="form-control">
                <option value="<?php echo $row['status']; ?>"><?php echo $row['status']; ?></option>
               <option value="Approve">Approve</option>
            <option value="Reject">Reject</option>
            </select>
          
        </div>
    </div>
    <form method="post"> 
            <input type="submit" value="Update" name="update"/> 
    </form>
</form>
</div>
</div>
</body>
</html>

<?php 
}else{
     header("Location: index2.php");
     exit();
}
 ?>